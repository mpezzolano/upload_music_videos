<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
        <title>WordPress &rsaquo; Notification</title>	
    </head>
    <body id="error-page">
        <link rel="stylesheet" href="<?php echo WP_PLUGIN_URL . '/inkmember/css/error.css'; ?>"/>
