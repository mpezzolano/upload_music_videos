﻿Plugin Name : InkmemberPro WordPress plugin

Created by : inkthemes.com

== Description ==

The Inkmember Pro is a content management plugin that allows to display premium content of your website which includes your product and services high-tech videos, audio, blogs, post, and pages to paid members only.
It is a one of the powerful and comprehensive tool which offers great content delivery to your member subscribers according to their requirement.
It is a platform for a business owner to sell their  genuine informative content to  potential customers, parallelly a resource for the customers
to make the choice to buy the type of content which is related to their field of interest.

This Plugin Works with all the [premium WordPress Themes](http://www.inkthemes.com).


= Features of 'InkmemberPro Plugin' =

* Can restrict most valuable and educative content  viewable to the paid members only.
* Make your website robust and enhance its credibility.
* Allows  option for one time purchase or recurring subscription.
* Provides integrated payment process by Paypal.
* Add multiple contents to be shown on your webpage.
* Allows  users to subscribe content for a particular period of time, this can be in days/week/month/year. Hence protect your content from malicious intent.
* Provides a handy WordPress dashboard which keeps  a record of your customers who have bought the contents from your website. 
  Payments paid by the customer can be tracked easily on the regular basis.
* Links that will help you to improve your website.

==Benefits==

* End-to-end content delivery to the paid members.
* Provides choice to your customer to access to the ace level of informative content according to their field of interest.
* Convert your generic site into Membership site and protect your content to fall into the wrong hands.
* Make your website�s versatile  and worthy  in front of users.
* Manageable and trackable  dashboard to keep your customer record updated.
 


= Support =

If you have any issues or need any help you can email me at enquiry@inkthemes.com.


== Installation ==

This section describes how to install the plugin and get it working.

1. Upload 'InkmemberPro' folder to the '/wp-content/plugins/' directory.
2. Activate the InkmemberPro plugin through the 'Plugins' menu in WordPress.
3. Activate the plugin.


== Changelog == 



= Version: 1.0.0 =
InkmemberPro WordPress plugin Initial Relaease.  
