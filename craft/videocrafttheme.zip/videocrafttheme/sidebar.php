<!--Start Sidebar-->
<div class="sidebar">
    <?php
    // Place widget area
    if (is_active_sidebar('primary-widget-area')) :
        dynamic_sidebar('primary-widget-area');
    endif;
    ?>   
</div>
<!--End Sidebar-->