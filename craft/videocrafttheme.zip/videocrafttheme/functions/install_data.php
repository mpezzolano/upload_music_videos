<?php

$post_data = array();
//Start Post 1
$post_meta = array();
$post_meta = array(
    '_video_url' => 'http://www.youtube.com/watch?v=bdt3Xp6Ma48',
    'featured_video' => 'on',
    'geocraft_dummy_content' => 1,
);
$post_data[] = array(
    "post_title" => 'This stle Blomsbury Hotel London consectetur',
    "post_content" => "<p>
'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.'
<br/>
'Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, nisi ut aliquid ex ea commodi consequatur? Quis autem vel eum iure reprehenderit qui in ea voluptate velit esse quam nihil molestiae consequatur, vel illum qui dolorem eum fugiat quo voluptas nulla pariatur?'
</p>",
    "post_meta" => $post_meta,
    "post_category" => array('Music', 'Entertainment', 'Sports'),
    "post_tags" => array('Tags', 'Cricket')
);
//End Post 1
//Start Post 2
$post_meta = array();
$post_meta = array(
    '_video_url' => 'http://www.youtube.com/watch?v=Oc0kdzwOLns',
    'featured_video' => 'on',
    'geocraft_dummy_content' => 1,
);
$post_data[] = array(
    "post_title" => 'The adipisicing Court Hotel Marble Arch London',
    "post_content" => "<p>
'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.'
<br/>
'Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, nisi ut aliquid ex ea commodi consequatur? Quis autem vel eum iure reprehenderit qui in ea voluptate velit esse quam nihil molestiae consequatur, vel illum qui dolorem eum fugiat quo voluptas nulla pariatur?'
</p>",
    "post_meta" => $post_meta,
    "post_category" => array('Entertainment', 'Sports'),
    "post_tags" => array('Tags', 'Film')
);
//End Post 2
//Start Post 3
$post_meta = array();
$post_meta = array(
    '_video_url' => 'http://www.youtube.com/watch?v=Oc0kdzwOLns',
    'featured_video' => 'on',
    'geocraft_dummy_content' => 1,
);
$post_data[] = array(
    "post_title" => 'The Rise Court Hotel Marble Arch London',
    "post_content" => "<p>
'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.'
<br/>
'Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, nisi ut aliquid ex ea commodi consequatur? Quis autem vel eum iure reprehenderit qui in ea voluptate velit esse quam nihil molestiae consequatur, vel illum qui dolorem eum fugiat quo voluptas nulla pariatur?'
</p>",
    "post_meta" => $post_meta,
    "post_category" => array('Entertainment', 'Music'),
    "post_tags" => array('Tags', 'Film')
);
//End Post 3
//Start Post 4
$post_meta = array();
$post_meta = array(
    '_video_url' => 'http://www.youtube.com/watch?v=hIYVeBFL6iA',
    'geocraft_dummy_content' => 1,
);
$post_data[] = array(
    "post_title" => 'Lorem ipsum dolor sit amet, consectetur adipisicing elit',
    "post_content" => "<p>
'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.'
<br/>
'Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, nisi ut aliquid ex ea commodi consequatur? Quis autem vel eum iure reprehenderit qui in ea voluptate velit esse quam nihil molestiae consequatur, vel illum qui dolorem eum fugiat quo voluptas nulla pariatur?'
</p>",
    "post_meta" => $post_meta,
    "post_category" => array('Sports', 'Music'),
    "post_tags" => array('Tags', 'Horror', 'Action')
);
//End Post 4
//Start Post 5
$post_meta = array();
$post_meta = array(
    '_video_url' => 'http://www.youtube.com/watch?v=9HOQeQo6Bbc',
    'featured_video' => 'on',
    'geocraft_dummy_content' => 1,
);
$post_data[] = array(
    "post_title" => 'consectetur ipsum dolor sit amet, consectetur adipisicing elit',
    "post_content" => "<p>
'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.'
<br/>
'Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, nisi ut aliquid ex ea commodi consequatur? Quis autem vel eum iure reprehenderit qui in ea voluptate velit esse quam nihil molestiae consequatur, vel illum qui dolorem eum fugiat quo voluptas nulla pariatur?'
</p>",
    "post_meta" => $post_meta,
    "post_category" => array('Music', 'Entertainment', 'Sports'),
    "post_tags" => array('Tags', 'Horror', 'Action')
);
//End Post 5
insert_listing_data1($post_data);

function insert_listing_data1($post_data) {
    global $wpdb, $current_user;
    for ($i = 0; $i < count($post_data); $i++) {
        $post_title = $post_data[$i]['post_title'];
        $post_count = $wpdb->get_var("SELECT count(ID) FROM $wpdb->posts where post_title like \"$post_title\" and post_type='" . 'video_listing' . "' and post_status in ('publish','draft')");
        if (!$post_count) {
            $post_data_array = array();
            $catids_arr = array();
            $my_post = array();
            $post_data_array = $post_data[$i];
            $my_post['post_title'] = $post_data_array['post_title'];
            $my_post['post_content'] = $post_data_array['post_content'];
            $my_post['post_type'] = 'video_listing';
            if (isset($post_data_array['post_author'])) {
                $my_post['post_author'] = $post_data_array['post_author'];
            } else {
                $my_post['post_author'] = 1;
            }
            $my_post['post_status'] = 'publish';
            $my_post['post_category'] = $post_data_array['post_category'];
            $my_post['tags_input'] = $post_data_array['post_tags'];
            $last_postid = wp_insert_post($my_post);
            wp_set_object_terms($last_postid, $post_data_array['post_category'], $taxonomy = 'video_cat');
            wp_set_object_terms($last_postid, $post_data_array['post_tags'], $taxonomy = 'video_tag');

            $post_meta = $post_data_array['post_meta'];
            if ($post_meta) {
                foreach ($post_meta as $mkey => $mval) {
                    update_post_meta($last_postid, $mkey, $mval);
                }
            }
            if (isset($post_data_array['post_image'])) {
                $post_image = $post_data_array['post_image'];
            } else {
                $post_image = false;
            }

            if ($post_image) {
                for ($m = 0; $m < count($post_image); $m++) {
                    $menu_order = $m + 1;
                    $image_array = explode('/', $post_image[$m]);
                    $img_name = $image_array[count($image_array) - 1];
                    $img_name_arr = explode('.', $img_name);
                    $post_img = array();
                    $post_img['post_title'] = $img_name_arr[0];
                    $post_img['post_status'] = 'attachment';
                    $post_img['post_parent'] = $last_postid;
                    $post_img['post_type'] = 'attachment';
                    $post_img['post_mime_type'] = 'image/jpeg';
                    $post_img['menu_order'] = $menu_order;
                    $last_postimage_id = wp_insert_post($post_img);
                    update_post_meta($last_postimage_id, '_wp_attached_file', $post_image[$m]);
                    $post_attach_arr = array(
                        "width" => 580,
                        "height" => 480,
                        "hwstring_small" => "height='100' width='100'",
                        "file" => $post_image[$m],
                    );
                    wp_update_attachment_metadata($last_postimage_id, $post_attach_arr);
                }
            }
        }
    }
}
