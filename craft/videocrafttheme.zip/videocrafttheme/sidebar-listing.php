<!--Start Sidebar-->
<div class="sidebar">
    <?php
    // Place widget area
    if (is_active_sidebar('listing-widget-area')) :
        dynamic_sidebar('listing-widget-area');
    endif;
    ?>

</div>
<!--End Sidebar-->