<?php
define('NB_VERSION', '1.0');
define('NB_DIR', wp_make_link_relative(plugins_url("", __FILE__)));
define('NB_SITEURL', wp_make_link_relative(site_url()));
define('NB_URL', plugins_url("", __FILE__));
define('NB_DB_VERSION', '0.9');
?>