﻿=== InfoBar Pro ===
Contributors: PankajAgarwal
Tags: info bar, infobar, message bar, notice bar, attention bar, notification, notification bar, highlight bar, sticky head, floating head, quick notice bar, popup bar, popup bar with custom message
Requires at least: 3.5.0
Tested up to: 3.9.1
Stable tag: 1.4

A easy and quick way to add top notification bar and call to action for your site. Easy way to grab visitors attention. Tell them about specific page.


== Description ==

A quick and easy way to add top notification bar and call to action for your WordPress website. 
It is important to provide the front visibility of your latest announcements in gist, on your website’s front-view, as it proves to be the effective communication tool to convey your latest updates to viewers, about your most appealing deals on website. Besides, when you release a new product, it should be highlighted on the top of your website so that it should be able to draw visitor's attention frequently when they visit your site.

In order to meet this objective InfoBar Top Notification plugin is a great option.InfoBar Top Notification plugin is a website’s element that displays important messages/announcements/communique/bulletin/statistics to your viewers in a single statement. It is going to be displayed in the extreme top area of your website.If you want to promote your products or notify your customers about your latest emerging e-services, Infobar plugin is the key to perform the task for you.

[InfoWay Premium WordPress Theme](http://www.inkthemes.com/wp-themes/infoway-wordpress-theme-with-built-in-lead-capture/) that is already have integrated with Notification bar system. So if you are looking for some very unique way of promote yourself InfoWay is the great option.

When the visitors visit your website/blog first thing that grab user attention is top notification bar. 

Notification Bar is used to show latest happening on your website. You can use it to display Free offers, Contact Page links, You can grab attention to premium content, discount offers, distribution of E-Book, Help you to get feedback from your customers and much more.

This Plugin Works with all the [premium WordPress Themes](http://www.inkthemes.com).


= Features of Infobar WP Plugin =

* The plugin is simple and easy to use.
* You can highlight the most important content of your website.
* The content will be displayed on the top of the website.
* It will help to redirect the use to other pages.
* Chances of maximum click on the content.
* You can promote any useful content.
* It will help to improve your website’s statistics.
* Sticky Notification Bar. 
* Choose color to match it to your site.
* Your can create unlimited InfoBar Notification.
* You can rebrand it, by putting your own logo on it.
* Compatible with Latest version of WordPress
* Suport Icon on Top Notification Bar
* Attract Users Attention
* Customize Color to your choice by using color picker tools.(Manage Background Color and text color the notification bar strip).
* You can collect leads.
* Integrated with email marketing services.
* Responsive design.

Links that will help you to improve your website.


1. [FormGet Contact Form](http://wordpress.org/plugins/formget-contact-form/).
2. [Sliding Contact Form By FormGet](http://wordpress.org/plugins/sliding-contact-form-by-formget/).
3. [Contact Form Integrated With Google Maps](http://wordpress.org/plugins/contact-form-integrated-with-google-maps/).
4. [Custom online form building](http://www.formget.com/).

= Support =

If you have any issues or need any help you can email me at pankajguna000@gmail.com.


== Installation ==

This section describes how to install the plugin and get it working.

1. Upload ` InfoBar` folder to the `/wp-content/plugins/` directory.
2. Activate the InfoBar plugin through the 'Plugins' menu in WordPress.
3. Activate the plugin.


== Changelog ==

= 1.4 =
* Design made Responsive.
* You can even collect leads into your database.
* Download list into any given file format.  
* Fixed database query error.
* Fixed fetal errors.
* Make Plugin Translation ready in German and Spanish Language.

= 1.3 =
* Collect leads. 
* Integrated with email marketing services.
* Fields are validated.

= 1.2 =
* Notification type can be editted.
* other issues resolved.

= 1.1 =
* default color set.
* iframe bug fixed.
* bar type added.

= 1.1 =
* default color set.
* iframe bug fixed.
* bar type added.

= 1.0  =
* Initial release


== Upgrade Notice ==
= 1.0 =
* Initial release
